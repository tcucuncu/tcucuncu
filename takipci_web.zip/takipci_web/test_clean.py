# -*- coding: utf-8 -*-
"""
Created on Fri Oct 17 15:57:23 2025

@author: user
"""

from flask import Flask
app = Flask(__name__)

@app.route("/")
def home():
    return "<h1 style='color:lime'>✅ Bu sayfa yeni Flask sunucusundan geliyor!</h1>"

if __name__ == "__main__":
    app.run(debug=False, use_reloader=False, port=5003)
